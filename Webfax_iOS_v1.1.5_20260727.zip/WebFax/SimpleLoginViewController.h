//
//  LoginViewController.h
//  WebFax2
//
//  Created by Seungil Shin on 2021/06/13.
//
#import <UIKit/UIKit.h>

@interface SimpleLoginViewController : UIViewController 
{
}

@property (assign, nonatomic) BOOL isLogin;
@property (assign, nonatomic) BOOL isChangePWD;


@end

