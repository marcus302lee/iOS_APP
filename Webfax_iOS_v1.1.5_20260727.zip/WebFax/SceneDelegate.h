//
//  SceneDelegate.h
//  WebViewTest
//
//  Created by Seungil Shin on 2021/12/07.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

