//
//  NSString+AESCrypt.h
//
//  AES128Encryption + Base64Encoding
//

#import "NSString+AESCrypt.h"

@implementation NSString (AESCrypt)

- (NSString*)AES128EncryptWithKey:(NSString*)key vector:(NSString*)vector
{
    NSData* plainData = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSData* encryptedData = [plainData AES128EncryptWithKey:key vector:vector];
    
    NSString* encryptedString = [encryptedData base64EncodedStringWithOptions:(NSDataBase64EncodingOptions)0];
    
	encryptedString = [encryptedString stringByReplacingOccurrencesOfString:@"+" withString:@"|"];
	encryptedString = [encryptedString stringByReplacingOccurrencesOfString:@"=" withString:@"_"];
//		encryptedString = [encryptedString stringByReplacingOccurrencesOfString:@"_" withString:@"_"];
    return encryptedString;
}

- (NSString*)AES128DecryptWithKey:(NSString*)key vector:(NSString*)vector
{
	NSString* convertedString = [self stringByReplacingOccurrencesOfString:@"|" withString:@"+"];
	convertedString = [convertedString stringByReplacingOccurrencesOfString:@"_" withString:@"="];
    
    
    NSData* encryptedData = [[NSData alloc] initWithBase64EncodedString:convertedString options:NSDataBase64DecodingIgnoreUnknownCharacters];
    NSData* plainData = [encryptedData AES128DecryptWithKey:key vector:vector];

    NSString* plainString = [[NSString alloc] initWithData:plainData encoding:NSUTF8StringEncoding];

    return plainString;
}

@end
