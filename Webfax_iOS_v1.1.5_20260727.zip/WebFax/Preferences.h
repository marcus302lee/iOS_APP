//
//  Preferences.h
//  WebFax2
//
//  Created by Seungil Shin on 2021/06/13.
//

#ifndef Preferences_h
#define Preferences_h

@interface Preferences : NSObject

+ (Preferences *)sharedPreferences;

@property (nonatomic, retain) NSString *userID;
@property (nonatomic, retain) NSString *userPW;
@property (nonatomic, retain) NSString *simpleLogin;
@property (nonatomic) BOOL useSimple;
@property (nonatomic) BOOL useBioLogin;
@property (nonatomic, retain) NSString *faxURL;
@property (nonatomic, retain) NSString *faxHost;
@property (nonatomic) BOOL showPermission;

- (void)save;

@end

#endif /* Preferences_h */
