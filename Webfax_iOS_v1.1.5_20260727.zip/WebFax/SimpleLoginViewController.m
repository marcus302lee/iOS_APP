//
//  LoginViewController.m
//  WebFax2
//
//  Created by Seungil Shin on 2021/06/13.
//

#import <Foundation/Foundation.h>
#import "SimpleLoginViewController.h"
#import "Preferences.h"
#import "AppDelegate.h"
#import "ViewController.h"

@interface SimpleLoginViewController ()
{
    BOOL isConfirm;
    int tryCount;
}
@property (weak, nonatomic) IBOutlet UIView *circleView;
@property (weak, nonatomic) IBOutlet UILabel *message1;
@property (weak, nonatomic) IBOutlet UILabel *message2;
@property (weak, nonatomic) IBOutlet UIView *keyView;
@property (weak, nonatomic) IBOutlet UIButton *okButton;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (nonatomic,retain) NSString *code;
@property (nonatomic,retain) NSString *inputCode;
@property (weak, nonatomic) IBOutlet UIView *passview;
@property (weak, nonatomic) IBOutlet UIView *topview;

@end

@implementation SimpleLoginViewController

- (void)viewDidLoad {
//    UIDevice *dev = [UIDevice currentDevice];
//    NSString *naem = dev.name;              // e.g. "My iPhone"
//    NSString *model = dev.model;              // e.g. "My iPhone"
//    NSString *systemVersion = dev.systemVersion;              // e.g. "My iPhone"

    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    CGSize statusBarSize = [[UIApplication sharedApplication]statusBarFrame].size;
    CGRect r = [_topview frame];
    r.origin.y += statusBarSize.height;
    _topview.frame = r;
//    _cancelButton.layer.cornerRadius = 5;
//    _cancelButton.layer.masksToBounds = YES;
//    _okButton.layer.cornerRadius = 5;
//    _okButton.layer.masksToBounds = YES;
    _code = @"";
    _inputCode = @"";
    for(UIView *dotView in _circleView.subviews) {
        dotView.layer.cornerRadius = dotView.frame.size.width/2.0;
        dotView.layer.masksToBounds = YES;
    }
    int width = self.view.frame.size.width/3.0;
    for(UIButton *keyButton in _keyView.subviews) {
        CGRect r = keyButton.frame;
        r.size.width = width;
        if(r.origin.x == 0) r.origin.x = self.view.frame.size.width/2.0 - width - width/2.0;
        else if(r.origin.x > self.view.frame.size.width/2.0) r.origin.x = self.view.frame.size.width/2.0 + width/2.0;
        else r.origin.x = self.view.frame.size.width/2.0 - width/2.0;
        keyButton.frame = r;
    }
    float pos = 0;
    for(int i = 0; i < 5; i++) {
        UIView *aview = [[UIView alloc] initWithFrame:CGRectMake(0, pos, self.view.frame.size.width, 1)];
        aview.backgroundColor = [UIColor colorWithRed:211.0/256.0 green:211.0/256.0 blue:211.0/256.0 alpha:1.0];
        [_keyView addSubview:aview];
        pos += _keyView.frame.size.height / 4.0;
    }
    pos = width;
    for(int i = 0; i < 2; i++) {
        UIView *aview = [[UIView alloc] initWithFrame:CGRectMake(pos, 0, 1, _keyView.frame.size.height)];
        aview.backgroundColor = [UIColor colorWithRed:211.0/256.0 green:211.0/256.0 blue:211.0/256.0 alpha:1.0];
        [_keyView addSubview:aview];
        pos += width;
    }
    tryCount = 0;
}

- (void)updatePreferences
{
//    [Preferences sharedPreferences].saveID = self->btnSaveID.selected;
    [[Preferences sharedPreferences] save];

}

- (IBAction)inputNumber:(id)sender {
    if([sender tag] < 0) {
        if(_code.length > 0) _code = [_code substringToIndex:_code.length-1];
    }
    else if(_code.length < 6) _code = [NSString stringWithFormat:@"%@%@", _code, [sender titleLabel].text];
    for(int i = 0; i < 6; i++) {
        UIView *dotview = [_circleView viewWithTag:i+1];
        if([_code length] > i) dotview.backgroundColor = [UIColor colorWithRed:224.0/256.0 green:61.0/256.0 blue:124.0/256.0 alpha:1.0];
        else dotview.backgroundColor = [UIColor colorWithRed:211.0/256.0 green:211.0/256.0 blue:211.0/256.0 alpha:1.0];
    }
//    if(_code.length == 6) _okButton.backgroundColor = [UIColor colorWithRed:224.0/256.0 green:61.0/256.0 blue:124.0/256.0 alpha:1.0];
//    else _okButton.backgroundColor = [UIColor colorWithRed:211.0/256.0 green:211.0/256.0 blue:211.0/256.0 alpha:1.0];

    if(_code.length == 6) [self done:self];
}

- (IBAction)closeSimple:(id)sender {
    id pvc = self.presentingViewController;
    if(sender == nil || _isLogin) {
        UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ViewController *vc = [s_board instantiateViewControllerWithIdentifier:@"mainVC"];

        
        vc.loadURL = Preferences.sharedPreferences.faxURL;
        vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        if(sender == self) {
            [pvc dismissViewControllerAnimated:YES completion:^{
                [pvc presentViewController:vc animated:YES completion:NULL];
            }];
        }
        else if(sender) {
            
            UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil  message:@"로그인 페이지로 이동합니다."
                                           preferredStyle:UIAlertControllerStyleAlert];
            [Preferences sharedPreferences].simpleLogin = nil;
            [Preferences sharedPreferences].useSimple = NO;
            [[Preferences sharedPreferences] save];

            UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault
               handler:^(UIAlertAction * action) {
                [pvc dismissViewControllerAnimated:YES completion:^{
                    [pvc presentViewController:vc animated:YES completion:NULL];
                }];
            }];
            [alert addAction:defaultAction];
            [self presentViewController:alert animated:YES completion:nil];
        }
        else {
            UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil  message:@"간편 로그인 비밀번호 설정을 취소하시겠습니까?" preferredStyle:UIAlertControllerStyleAlert];

            UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault
               handler:^(UIAlertAction * action) {
                [pvc dismissViewControllerAnimated:YES completion:^{
                     [pvc presentViewController:vc animated:YES completion:NULL];
                 }];
            }];
            UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"취소" style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
            }];
            [alert addAction:defaultAction];
            [alert addAction:cancelAction];
            [self presentViewController:alert animated:YES completion:nil];
        }
    } 
    else {
        if(sender) {
            UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil  message:@"간편 로그인 비밀번호 설정을 취소하시겠습니까?" preferredStyle:UIAlertControllerStyleAlert];

            UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault
               handler:^(UIAlertAction * action) {
                [Preferences sharedPreferences].useSimple  = NO;
                [Preferences sharedPreferences].useBioLogin = NO;
                [Preferences sharedPreferences].simpleLogin = nil;
                [[Preferences sharedPreferences] save];
                [pvc dismissViewControllerAnimated:YES completion:^{
                    [pvc performSelector:@selector(reloadView)];
                }];
            }];
            UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"취소" style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
            }];
            [alert addAction:defaultAction];
            [alert addAction:cancelAction];
            [self presentViewController:alert animated:YES completion:nil];
        }
        else {
            [pvc dismissViewControllerAnimated:YES completion:^{
            }];
        }
    }
}

- (BOOL)isInvalidCode:(NSString *)code {
    for(int i = 0; i < 10; i++) {
        NSString *str = [NSString stringWithFormat:@"%d%d%d", i, i , i];
        if([code containsString:str]) return YES;
    }
    for(int i = 0; i < 8; i++) {
        NSString *str = [NSString stringWithFormat:@"%d%d%d", i, i+1, i+2];
        if([code containsString:str]) return YES;
    }
    return NO;
}

- (IBAction)done:(id)sender
{
    if(_isLogin) {
        id pvc = self.presentingViewController;
        if([[Preferences sharedPreferences].simpleLogin isEqualToString:_code]) {
            UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            ViewController *main_vc = [s_board instantiateViewControllerWithIdentifier:@"mainVC"];
            main_vc.loadURL = Preferences.sharedPreferences.faxURL;  // go to mypage
            main_vc.isLoggined = YES;
            main_vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
            main_vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
            [pvc dismissViewControllerAnimated:YES completion:^{
                [pvc presentViewController:main_vc animated:YES completion:NULL];
            }];
        }
        else {
            tryCount++;
            _message1.text = [NSString stringWithFormat:@"비밀번호가 일치하지 않습니다. (%d/5)", tryCount];
            _code = @"";
            if(tryCount > 4) {
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil  message:@"비밀번호 5회 실패로 로그인 페이지로 이동합니다."
                                               preferredStyle:UIAlertControllerStyleAlert];
                [Preferences sharedPreferences].simpleLogin = nil;
                [Preferences sharedPreferences].useSimple = NO;
                [[Preferences sharedPreferences] save];

                UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault
                   handler:^(UIAlertAction * action) {
                    [self closeSimple:self];
                }];

                [alert addAction:defaultAction];
                [self presentViewController:alert animated:YES completion:nil];
                return;
            }
            for(int i = 0; i < 6; i++) {
                UIView *dotview = [_circleView viewWithTag:i+1];
                dotview.backgroundColor = [UIColor colorWithRed:211.0/256.0 green:211.0/256.0 blue:211.0/256.0 alpha:1.0];
            }
            UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil  message:@"간편 비밀번호가 일치하지 않습니다."
                                           preferredStyle:UIAlertControllerStyleAlert];

            UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault
               handler:^(UIAlertAction * action) {
            }];
             
            [alert addAction:defaultAction];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }
    else {
        if(isConfirm) {
            if([_inputCode isEqualToString:_code]) {
                [Preferences sharedPreferences].simpleLogin = _code;
                [Preferences sharedPreferences].useSimple = YES;

                [[Preferences sharedPreferences] save];
//                UIViewController *pvc = self.presentingViewController;
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil
                                                        message:@"간편 로그인 비밀번호가 설정되었습니다."
                                                        preferredStyle:UIAlertControllerStyleAlert];


                UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
                        id pvc = self.presentingViewController;
                        [pvc dismissViewControllerAnimated:YES completion:^{
                        }];
                }];
                 
                [alertController addAction:defaultAction];
                [self presentViewController:alertController animated:YES completion:^{}];
            }
            else {
//                _message1.text = @"비밀번호가 일치하지 않습니다.";
                _code = @"";
                tryCount++;
                for(int i = 0; i < 6; i++) {
                    UIView *dotview = [_circleView viewWithTag:i+1];
                    dotview.backgroundColor = [UIColor colorWithRed:211.0/256.0 green:211.0/256.0 blue:211.0/256.0 alpha:1.0];
                }
                if(tryCount > 4) {
                    UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil  message:@"비밀번호가 일치하지 않습니다. 처음부터 다시 시도해 주세요."
                                                   preferredStyle:UIAlertControllerStyleAlert];
                    _message1.text = @"비밀번호를 입력해 주세요.";
                    _inputCode = @"";
                    isConfirm = NO;
                    _message2.hidden = YES;
                    tryCount = 0;

                    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault
                       handler:^(UIAlertAction * action) {
                    }];
                     
                    [alert addAction:defaultAction];
                    [self presentViewController:alert animated:YES completion:nil];
                }
                else {
                    UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil  message:@"비밀번호가 일치하지 않습니다."
                                               preferredStyle:UIAlertControllerStyleAlert];

                    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault
                       handler:^(UIAlertAction * action) {
                    }];
                     
                    [alert addAction:defaultAction];
                    [self presentViewController:alert animated:YES completion:nil];
                }
           }
        }
        else {
            if([self isInvalidCode:_code]) {
                
//                _message1.text = @"3자리 이상 연속되거나 동일한 숫자는 설정 할 수 없습니다.";
                _message2.hidden = YES;
                _code = @"";

                UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil  message:@"3자리 이상 연속되거나 동일한 숫자는 설정 할 수 없습니다."
                                               preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault
                   handler:^(UIAlertAction * action) {
                    for(int i = 0; i < 6; i++) {
                        UIView *dotview = [[self circleView] viewWithTag:i+1];
                        dotview.backgroundColor = [UIColor colorWithRed:211.0/256.0 green:211.0/256.0 blue:211.0/256.0 alpha:1.0];
                    }
//                    _okButton.backgroundColor = [UIColor colorWithRed:211.0/256.0 green:211.0/256.0 blue:211.0/256.0 alpha:1.0];
                }];
                 
                [alert addAction:defaultAction];
                [self presentViewController:alert animated:YES completion:nil];
               return;
            }

            _inputCode = _code;
            _code = @"";
            isConfirm = YES;
            for(int i = 0; i < 6; i++) {
                UIView *dotview = [_circleView viewWithTag:i+1];
                dotview.backgroundColor = [UIColor colorWithRed:211.0/256.0 green:211.0/256.0 blue:211.0/256.0 alpha:1.0];
            }
//            _okButton.backgroundColor = [UIColor colorWithRed:211.0/256.0 green:211.0/256.0 blue:211.0/256.0 alpha:1.0];
            _message1.text = @"확인을 위해 다시 한번 입력해 주세요.";
            _message2.hidden = YES;
        }
    }
    //    [Preferences sharedPreferences].saveID = self->btnSaveID.selected;
    
}

@end

