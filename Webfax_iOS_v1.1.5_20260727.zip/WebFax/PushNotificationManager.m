//
//  PushNotificationManager.m
//  WebFax
//
//  Created by Kim BaeSung on 2021/12/13.
//

#import "PushNotificationManager.h"

@import FirebaseMessaging;
@import UserNotifications;

@interface PushNotificationManager () <FIRMessagingDelegate, UNUserNotificationCenterDelegate>

@property (assign, nonatomic) NSString* fcmToken;

@end


@implementation PushNotificationManager

+ (instancetype)sharedInstance
{
    static PushNotificationManager *_sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[PushNotificationManager alloc] init];
    });
    
    return _sharedInstance;
}


#pragma mark - Initialize method
- (id)init
{
    if ((self = [super init])) {
        [[FIRMessaging messaging] setDelegate:self];
    }
    
    return self;
}



#pragma mark - Request push notification permissions
- (void)registerForRemoteNotifications
{
    UIApplication *sharedApplication = [UIApplication sharedApplication];
    UNUserNotificationCenter *notificationCenter = [UNUserNotificationCenter currentNotificationCenter];
    [notificationCenter setDelegate:self];
    
    [notificationCenter getNotificationSettingsWithCompletionHandler:^(UNNotificationSettings * _Nonnull settings) {
        switch (settings.authorizationStatus)
        {
            case UNAuthorizationStatusNotDetermined:
            {
                UNAuthorizationOptions authOptions = (UNAuthorizationOptionAlert | UNAuthorizationOptionSound);
                [notificationCenter requestAuthorizationWithOptions:authOptions
                                                  completionHandler:^(BOOL granted, NSError * _Nullable error) {
                                                    if (granted)
                                                    {
                                                        dispatch_sync(dispatch_get_main_queue(), ^{
                                                            [sharedApplication registerForRemoteNotifications];
                                                        });
                                                    }
                                                  }];
                break;
            }
                
            case UNAuthorizationStatusDenied:
            {
                break;
            }
                
            case UNAuthorizationStatusAuthorized:
            {
                dispatch_sync(dispatch_get_main_queue(), ^{
                    [sharedApplication registerForRemoteNotifications];
                });
                break;
            }
                
            default:
                break;
        }
    }];
}


#pragma mark - FIRMessaging delegate method
- (void)messaging:(FIRMessaging *)messaging didReceiveRegistrationToken:(NSString *)fcmToken
{
    NSLog(@"FCM registration token: %@", fcmToken);
    
    self.fcmToken = fcmToken;
    
    // Notify about received token.
    NSDictionary *dataDict = [NSDictionary dictionaryWithObject:fcmToken forKey:@"token"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"FCMToken" object:nil userInfo:dataDict];
    
    
}

-(NSString*)getFcmToken {
    return self.fcmToken;
}


#pragma mark - iOS 10 이상 push delegate
- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler
{
    completionHandler(UNNotificationPresentationOptionAlert | UNNotificationPresentationOptionSound);
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler
{
    NSDictionary *userInfo = response.notification.request.content.userInfo;
    NSLog(@"UNUserNotificationCenterDelegate didReceive response: %@", userInfo);

    completionHandler();
}


@end
