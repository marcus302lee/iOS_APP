//
//  AppDelegate.m
//  WebViewTest
//
//  Created by Seungil Shin on 2021/12/07.
//

#import "AppDelegate.h"
#import "PushNotificationManager.h"
#import "Utils.h"

@interface AppDelegate ()

@end


@implementation AppDelegate

+ (AppDelegate *)sharedAppDelegate {
    return (AppDelegate *) [UIApplication sharedApplication].delegate;
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [[Utils sharedInstance] startNetworkMonitoring];
    
    // Firebase initialize
    [FIRApp configure];
    
    // Push Notification initialize
   // [[PushNotificationManager sharedInstance] registerForRemoteNotifications];
    
    
    return YES;
}

- (void)regRemoteNotification {
    [[PushNotificationManager sharedInstance] registerForRemoteNotifications];
}


/*#pragma mark - Get push registrationToken methods
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(nonnull NSData *)deviceToken
{
    NSString *deviceTokenString = [[[[deviceToken description]
                                     stringByReplacingOccurrencesOfString: @"<" withString: @""]
                                    stringByReplacingOccurrencesOfString: @">" withString: @""]
                                   stringByReplacingOccurrencesOfString: @" " withString: @""];
    NSLog(@"[AppDelegate] push device token string: %@", deviceTokenString);
}


#pragma mark - push token registration failed
-(void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    NSLog(@"Error : %@",error);
}*/


#pragma mark - UISceneSession lifecycle
- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options  API_AVAILABLE(ios(13.0)) {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions API_AVAILABLE(ios(13.0)) {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
