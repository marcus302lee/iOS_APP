//
//  Utils.m
//  WebFax
//
//  Created by Kim BaeSung on 2021/12/16.
//

#import "Utils.h"
#import "AppDelegate.h"
#import "TargetConditionals.h"

@interface Utils ()

@property (assign, nonatomic) AFNetworkReachabilityStatus networkStatus;

@end


@implementation Utils

+ (id)sharedInstance
{
    static Utils *_sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}


#pragma mark - Network monitoring methods
- (void)startNetworkMonitoring
{
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    _networkStatus = AFNetworkReachabilityStatusUnknown;
    
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        self->_networkStatus = status;
        switch (self->_networkStatus)
        {
            case AFNetworkReachabilityStatusNotReachable:
                [self showNoConnectivityAlert];
                break;
                
            case AFNetworkReachabilityStatusUnknown:
            case AFNetworkReachabilityStatusReachableViaWWAN:
            case AFNetworkReachabilityStatusReachableViaWiFi:
            default:
                break;
        }
    }];
}

- (void)stopNetworkMonitoring
{
    [[AFNetworkReachabilityManager sharedManager] stopMonitoring];
}

- (AFNetworkReachabilityStatus)getCurNetworkStatus
{
    return _networkStatus;
}


#pragma mark -
- (void)showNoConnectivityAlert
{
    AppDelegate *appDelegate = [AppDelegate sharedAppDelegate];
    UIViewController *rootViewController = [appDelegate rootViewController];
    UIViewController *presentedViewController = [rootViewController presentedViewController];
    if (!presentedViewController)
    {
        presentedViewController = rootViewController;
    }
    
    if (presentedViewController)
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"네크워크 오류"
                message:@"서버에 접속할 수 없습니다. 단말에서 모바일 데이터 혹은 와이파이가 정상 연결되었는지 확인 하신 후 다시 접속해 주시기 바랍니다."
                                                                          preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *actionOK = [UIAlertAction actionWithTitle:@"확인"
                                                          style:UIAlertActionStyleDefault
                                                        handler:^(UIAlertAction * _Nonnull action) {
            exit(1);
        }];
        [alertController addAction:actionOK];
        
        [presentedViewController presentViewController:alertController
                                              animated:NO
                                            completion:^{
            
        }];
    }
}

- (BOOL)isFileExistAtPath:(NSString*)filePath
{
#ifdef DEBUG
    BOOL ret = [[NSFileManager defaultManager] fileExistsAtPath:filePath];
    if( ret ) {
        return YES;
    }
#else
    return [[NSFileManager defaultManager] fileExistsAtPath:filePath];
#endif
    
    return NO;
    
}

- (BOOL)isOpenFile:(NSString*)filePath
{
    char const *path_cstr = [[NSFileManager defaultManager] fileSystemRepresentationWithPath:filePath];
    FILE *file = fopen(path_cstr, "r");
    if (file == nil)
    {
        return NO;
    }
    fclose(file);
    return YES;
}

- (BOOL)isWriteToFile:(NSString*)filePath
{
    @try {
        return [@"check_private" writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
    @catch (NSException *e) {
        return NO;
    }
}

- (BOOL)isJailBroken
{
    if ([self isFileExistAtPath:@"/Applications/Cydia.app"] ||
        
        [self isFileExistAtPath:@"/Applications/FakeCarrier.app"] ||
        [self isFileExistAtPath:@"/Applications/MxTube.app"] ||
        [self isFileExistAtPath:@"/Applications/SBSettings.app"] ||
        [self isFileExistAtPath:@"/Applications/RockApp.app"] ||
        [self isFileExistAtPath:@"/Applications/Icy.app"] ||
        [self isFileExistAtPath:@"/Applications/WinterBoard.app"] ||
        [self isFileExistAtPath:@"/Applications/SBSetttings.app"] ||
        [self isFileExistAtPath:@"/Applications/blackra1n.app"] ||
        [self isFileExistAtPath:@"/Applications/IntelliScreen.app"] ||
        [self isFileExistAtPath:@"/Applications/Snoop-itConfig.app"] ||
        
        [self isFileExistAtPath:@"/Library/MobileSubstrate/MobileSubstrate.dylib"] ||
        [self isFileExistAtPath:@"/etc/apt"] ||
        [self isFileExistAtPath:@"/private/var/lib/apt/"] ||
        [self isOpenFile:@"/Applications/Cydia.app"] ||
        [self isOpenFile:@"/Library/MobileSubstrate/MobileSubstrate.dylib"] ||
        
        [self isOpenFile:@"/etc/apt"] )
    {
        return YES;
    }
    
#if !TARGET_IPHONE_SIMULATOR
    if ([self isFileExistAtPath:@"/bin/bash"] || [self isOpenFile:@"/bin/bash"] ||
        [self isFileExistAtPath:@"/usr/sbin/sshd"] || [self isOpenFile:@"/usr/sbin/sshd"] ||
        [self isWriteToFile:@"/private/check_private.txt"] ) {
        return YES;
    }
#endif
    
    return NO;
}

- (BOOL)checkJailBreak
{
    if( [self isJailBroken] ) {
        AppDelegate *appDelegate = [AppDelegate sharedAppDelegate];
        UIViewController *rootViewController = [appDelegate rootViewController];
        UIViewController *presentedViewController = [rootViewController presentedViewController];
        if (!presentedViewController)
        {
            presentedViewController = rootViewController;
        }
        
        if (presentedViewController)
        {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"오류"
                                                                                     message:@"탈옥된 기기에서 사용할 수 없습니다."
                                                                              preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *actionOK = [UIAlertAction actionWithTitle:@"확인"
                                                               style:UIAlertActionStyleDefault
                                                             handler:^(UIAlertAction * _Nonnull action) {
                exit(1);
            }];
            [alertController addAction:actionOK];
            
            [presentedViewController presentViewController:alertController
                                                  animated:NO
                                                completion:^{
                
            }];
        }
        
        return YES;
    }
    
    return NO;
}

@end
