//
//  LoginPreference.h
//  WebFax2
//
//  Created by Seungil Shin on 2021/06/13.
//
#import <UIKit/UIKit.h>

@interface LoginPreference : UIViewController
{
}
- (void)reloadView;


@end

