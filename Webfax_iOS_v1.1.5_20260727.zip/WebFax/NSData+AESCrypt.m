//
//  NSData+AESCrypt.h
//
//  AES128Encryption + Base64Encoding
//  @tharindu http://tharindufit.wordpress.com
//
//
#import "NSData+AESCrypt.h"
#import <CommonCrypto/CommonCryptor.h>
#import "NSString+MD5.h"
#import "NSData+MD5.h"

@implementation NSData (AESCrypt)

int hexToInt(const char* szHex)
{
	int dec = 0; // 반환될 값. 초기에는 0이다.
	int nibble; // 16진수의 한 니블(4비트)값을 담아둘 곳
	
	while (*szHex)
	{
		dec <<= 4;
		
		if (*szHex >= '0' && *szHex <= '9') {
			nibble = *szHex - '0';
		} else if (*szHex >= 'a' && *szHex <= 'f') {
			nibble = *szHex - 'a' + 10;
		} else if (*szHex >= 'A' && *szHex <= 'F') {
			nibble = *szHex - 'A' + 10;
		} else {
			nibble = 0;
		}
		
		dec |= nibble;
		
		szHex++;
	}
	
	return dec;
}

- (NSData*)hex2bin:(NSString*)hexString
{
	NSMutableData* dataReturn = [[NSMutableData alloc] initWithCapacity:0];
	NSMutableString* mString = [[NSMutableString alloc] initWithCapacity:0];
	for (int i = 0; i < [hexString length]; ++i)
	{
		[mString appendFormat:@"%C", [hexString characterAtIndex:i]];
		
		if (2 == [mString length])
		{
			int integerValue = hexToInt([mString UTF8String]);
			[dataReturn appendBytes:&integerValue length:1];
			
			[mString setString:@""];
		}
	}
	
	if (2 == [mString length])
	{
		int integerValue = hexToInt([mString UTF8String]);
		[dataReturn appendBytes:&integerValue length:1];
		
		[mString setString:@""];
	}
	
	return dataReturn;
}

- (NSData*)AES128EncryptWithKey:(NSString *)key vector:(NSString*)vector
{
    // 'key' should be 16 bytes for AES128
    char keyPtr[kCCKeySizeAES128 + 1]; // room for terminator (unused)
    bzero( keyPtr, sizeof( keyPtr ) ); // fill with zeroes (for padding)
	
	// initial vector buffer
	char iv[kCCBlockSizeAES128 + 1];
	bzero(iv, sizeof(iv));
    
    // fetch key data
	NSString* md5key = [[key dataUsingEncoding:NSUTF8StringEncoding] md5String];
//	NSLog(@"md5key = [%@]", md5key);
	NSData* datakey = [self hex2bin:md5key];
//	NSLog(@"datakey length = [%d]", [datakey length]);
	memcpy(keyPtr, [datakey bytes], [datakey length]);
	
	// fetch initial vector data
	NSString* md5initvector = [[vector dataUsingEncoding:NSUTF8StringEncoding] md5String];
//	NSLog(@"md5initvector = [%@]", md5initvector);
	NSData* datainitvector = [self hex2bin:md5initvector];
//	NSLog(@"datainitvector length = [%d]", [datainitvector length]);
//	NSLog(@"datainitvector = [%@]", datainitvector);
	memcpy(iv, [datainitvector bytes], [datainitvector length]);
	
    NSUInteger dataLength = [self length];
    
    //See the doc: For block ciphers, the output size will always be less than or
    //equal to the input size plus the size of one block.
    //That's why we need to add the size of one block here
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc( bufferSize );
    
    size_t numBytesEncrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCEncrypt,
										  kCCAlgorithmAES128,
										  /*kCCOptionECBMode |*/ kCCOptionPKCS7Padding, // kCCOptionECBMode 를 생략하면 CBC 모드가 된다.
                                          keyPtr, kCCKeySizeAES128,
                                          iv, //NULL /* initialization vector (optional) */,
                                          [self bytes], dataLength, /* input */
                                          buffer, bufferSize, /* output */
                                          &numBytesEncrypted);
//	NSLog(@"cryptStatus = [%d]", cryptStatus);
    if( cryptStatus == kCCSuccess )
    {
        //the returned NSData takes ownership of the buffer and will free it on deallocation
        return [NSData dataWithBytesNoCopy:buffer length:numBytesEncrypted];
    }
    
    free( buffer ); //free the buffer
    return nil;
}

- (NSData*)AES128DecryptWithKey:(NSString *)key vector:(NSString*)vector
{
    // 'key' should be 16 bytes for AES128
    char keyPtr[kCCKeySizeAES128 + 1]; // room for terminator (unused)
    bzero( keyPtr, sizeof( keyPtr ) ); // fill with zeroes (for padding)
	
	// initial vector buffer
	char iv[kCCBlockSizeAES128 + 1];
	bzero(iv, sizeof(iv));
    
    // fetch key data
	NSString* md5key = [[key dataUsingEncoding:NSUTF8StringEncoding] md5String];
//	NSLog(@"md5key = [%@]", md5key);
	NSData* datakey = [self hex2bin:md5key];
//	NSLog(@"datakey length = [%d]", [datakey length]);
	memcpy(keyPtr, [datakey bytes], [datakey length]);
	
	// fetch initial vector data
	NSString* md5initvector = [[vector dataUsingEncoding:NSUTF8StringEncoding] md5String];
//	NSLog(@"md5initvector = [%@]", md5initvector);
	NSData* datainitvector = [self hex2bin:md5initvector];
//	NSLog(@"datainitvector length = [%d]", [datainitvector length]);
//	NSLog(@"datainitvector = [%@]", datainitvector);
	memcpy(iv, [datainitvector bytes], [datainitvector length]);
	
    NSUInteger dataLength = [self length];
    
    //See the doc: For block ciphers, the output size will always be less than or
    //equal to the input size plus the size of one block.
    //That's why we need to add the size of one block here
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc( bufferSize );
    
    size_t numBytesDecrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCDecrypt,
										  kCCAlgorithmAES128,
										  /*kCCOptionECBMode |*/ kCCOptionPKCS7Padding, // kCCOptionECBMode 를 생략하면 CBC 모드가 된다.
                                          keyPtr, kCCKeySizeAES128,
                                          iv, //NULL /* initialization vector (optional) */,
                                          [self bytes], dataLength, /* input */
                                          buffer, bufferSize, /* output */
                                          &numBytesDecrypted);
//	NSLog(@"cryptStatus = [%d]", cryptStatus);
    if( cryptStatus == kCCSuccess )
    {
        //the returned NSData takes ownership of the buffer and will free it on deallocation
        return [NSData dataWithBytesNoCopy:buffer length:numBytesDecrypted];
    }

    free( buffer ); //free the buffer
    return nil;
}

@end
