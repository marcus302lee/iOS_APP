//
//  PermViewController.h
//  WebFax
//
//  Created by Oh Hansub on 2/13/24.
//

#import <UIKit/UIKit.h>

@interface PermViewController : UIViewController
{
}

@end
