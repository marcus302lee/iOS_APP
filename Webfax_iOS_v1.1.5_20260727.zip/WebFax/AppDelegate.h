//
//  AppDelegate.h
//  WebViewTest
//
//  Created by Seungil Shin on 2021/12/07.
//

#import <UIKit/UIKit.h>
#define APP_DELEGATE (AppDelegate *)[[UIApplication sharedApplication] delegate]

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (retain, nonatomic) UIViewController *rootViewController;

+ (AppDelegate *)sharedAppDelegate;

- (void)regRemoteNotification;

@end

