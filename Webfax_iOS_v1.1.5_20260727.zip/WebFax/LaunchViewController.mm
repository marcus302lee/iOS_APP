//
//  LaunchViewController.m
//  lgupluscar
//
//  Created by Seungil Shin on 2021/09/05.
//

#import "LaunchViewController.h"
#import "AppDelegate.h"
#import "Preferences.h"
#import "ViewController.h"
#import "SimpleLoginViewController.h"
#import <LocalAuthentication/LocalAuthentication.h>
#import "Utils.h"
#import "PermViewController.h"

@interface LaunchViewController ()

@property (nonatomic, weak) IBOutlet UIImageView *imgLogo;
@property (nonatomic, weak) IBOutlet UILabel *label;


- (void)showUpdateAlert:(NSString *)url_str;

@end

@implementation LaunchViewController

- (void)sendRequest:(NSString *)method bodyDict:(NSDictionary *)body_dict completionHandler:(void (^)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHandler
{
    NSString *url_str = [NSString stringWithFormat:@"https://%@/appVersion.jsp",Preferences.sharedPreferences.faxHost];
    NSURL *url = [NSURL URLWithString:url_str];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];

    [request setHTTPMethod:method];

    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:request completionHandler:completionHandler] resume];
}

- (void)getLatestVersion:(void (^)(NSDictionary *, NSString *))completionHandler
{

    [self sendRequest:@"POST" bodyDict:nil completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            if(error == nil) {
                NSDictionary *res_info = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
                completionHandler(res_info, nil);
            }
            else {
                completionHandler(nil, error.localizedDescription);
                NSLog(@"loading failed!!! \n%@",error);
            }
        }
    ];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

-(void)useTouchID {
    NSError *error;
    LAContext *_laContext = [[LAContext alloc] init];

    if ([_laContext canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) { _laContext.localizedFallbackTitle = @"바이오";
        [_laContext evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:@"바이오" reply:^(BOOL succes, NSError *error) {
            if (succes) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    ViewController *main_vc = [s_board instantiateViewControllerWithIdentifier:@"mainVC"];
                    main_vc.isLoggined = YES;
                    main_vc.loadURL = Preferences.sharedPreferences.faxURL;
                    main_vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
                    main_vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
                    [self presentViewController:main_vc animated:YES completion:nil];
                });
            
            } else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    switch (error.code) {
                        case LAErrorAuthenticationFailed: { //@“터치ID 등록에 실패했습니다." //@“페이스ID 등록에 실패했습니다."
                            
                            }
                            break;
                        case LAErrorUserCancel: { //
                            
                            }
                            break;
                        case LAErrorUserFallback: break;
                        case LAErrorBiometryLockout: { //
                            
                            }
                            break;
                        default: { //
                            
                            }
                            break;
                            
                    }
                    UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    if([Preferences sharedPreferences].useSimple && [Preferences sharedPreferences].simpleLogin) {
                        SimpleLoginViewController *sc = [s_board instantiateViewControllerWithIdentifier:@"simple"];
                        sc.isLogin = YES;
                        sc.modalPresentationStyle = UIModalPresentationOverFullScreen;
                        sc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
                        [self presentViewController:sc animated:YES completion:nil];
                    }
                    else {
                        ViewController *main_vc = [s_board instantiateViewControllerWithIdentifier:@"mainVC"];
                        main_vc.loadURL = Preferences.sharedPreferences.faxURL;
                        main_vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
                        main_vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
                        [self presentViewController:main_vc animated:YES completion:nil];
                    }
                });
                
            }
            
        }];
       
    } else { //@“터치ID 설정을 확인하세요.” //@"페이스ID 설정을 확인하세요."
        UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ViewController *main_vc = [s_board instantiateViewControllerWithIdentifier:@"mainVC"];
        main_vc.loadURL = Preferences.sharedPreferences.faxURL;
        main_vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        main_vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentViewController:main_vc animated:YES completion:nil];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    /*CGRect rtLogo = CGRectZero;
    rtLogo.size = _imgLogo.frame.size;
    rtLogo.origin = CGPointMake(((self.view.bounds.size.width - rtLogo.size.width) / 2), 226);
    [_imgLogo setFrame:rtLogo];*/
}
                        
- (void)showMainController {
    [[AppDelegate sharedAppDelegate] regRemoteNotification];
    
    UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    if([Preferences sharedPreferences].useBioLogin) {
        [self useTouchID];
        return;
    }
    id havelogin = [Preferences sharedPreferences].simpleLogin;
    if([Preferences sharedPreferences].useSimple && havelogin) {
        SimpleLoginViewController *sc = [s_board instantiateViewControllerWithIdentifier:@"simple"];
        sc.isLogin = YES;
        sc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        sc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentViewController:sc animated:YES completion:nil];
    }
    else {
        ViewController *main_vc = [s_board instantiateViewControllerWithIdentifier:@"mainVC"];
        main_vc.loadURL = Preferences.sharedPreferences.faxURL;
        main_vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        main_vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentViewController:main_vc animated:YES completion:nil];
    }
}

- (void)showPermissionController {
    UIStoryboard *main = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    PermViewController* pvc = [main instantiateViewControllerWithIdentifier:@"perm"];
    pvc.modalPresentationStyle = UIModalPresentationOverFullScreen;
    pvc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentViewController:pvc animated:YES completion:nil];
}

- (void)viewDidAppear:(BOOL)animated {
    sleep(1);
    NSString *sbname = nil;
    [APP_DELEGATE setRootViewController:self];
    
    Utils *utils = [Utils sharedInstance];
    //[utils checkJailBreak];
    
    AFNetworkReachabilityStatus networkStatus = [utils getCurNetworkStatus];
    if (networkStatus == AFNetworkReachabilityStatusNotReachable)
    {
        [utils showNoConnectivityAlert];
        return;
    }
    
    NSMutableArray *arrAnimatingImages = [[NSMutableArray alloc] init];
    for (int i=0; i<36; i++)
    {
        // TODO: A4soft => splash_04, splash_05 파일이 이전 이미지라서 임시 제외 처리했음.
        if( i == 4 || i == 5 ) {
            continue;
        }
        NSString *strImgName = [NSString stringWithFormat:@"splash_%02d", i];
        UIImage *img = [UIImage imageNamed:strImgName];
        [arrAnimatingImages addObject:img];
    }
    [_imgLogo setAnimationImages:arrAnimatingImages];
    [_imgLogo setAnimationDuration:2.0f];
    [_imgLogo startAnimating];
    [self performSelector:@selector(goMainView)
               withObject:nil
               afterDelay:_imgLogo.animationDuration];
}

- (void)goMainView
{
    [self getLatestVersion:^(NSDictionary *ver_info, NSString *msg) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if( Preferences.sharedPreferences.showPermission ) {
                [self showMainController];
            }
            else {
                [self showPermissionController];
            }
            
        });
    }];
}

- (void)showUpdateAlert:(NSString *)url_str
{
    NSString *title = @"업데이트 안내";
    NSString *desc = @"버전이 업그레이드 되었습니다.\n업데이트 하시겠습니까?";

    UIAlertController* alert = [UIAlertController alertControllerWithTitle:title
                                   message:desc
                                   preferredStyle:UIAlertControllerStyleAlert];
     
    UIAlertAction* closeAction = [UIAlertAction actionWithTitle:@"취소" style:UIAlertActionStyleCancel
       handler:^(UIAlertAction * action) {
        [self showMainController];
    }];
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"업데이트" style:UIAlertActionStyleDefault
       handler:^(UIAlertAction * action) {
        
        // @"itms-apps://itunes.apple.com/app/apple-store/945578864"  // LGU+ 고객센터 앱
        NSURL *url = [NSURL URLWithString:url_str];
        NSDictionary *dict = [NSDictionary dictionary];
        [[UIApplication sharedApplication] openURL:url options:dict completionHandler:nil];
        exit(0);
    }];
    
    [alert addAction:closeAction];
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];
}


@end
