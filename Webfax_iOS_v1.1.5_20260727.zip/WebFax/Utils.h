//
//  Utils.h
//  WebFax
//
//  Created by Kim BaeSung on 2021/12/16.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFNetworking.h>

NS_ASSUME_NONNULL_BEGIN

#define IS_IPHONE                                       (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define SCREEN_WIDTH                                    ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT                                   ([UIScreen mainScreen].bounds.size.height)
#define SCREEN_MAX_LENGTH                               (MAX(SCREEN_WIDTH, SCREEN_HEIGHT))
#define IS_IPHONE_X_XS                                  (IS_IPHONE && SCREEN_MAX_LENGTH == 812.0)
#define IS_IPHONE_XSMAX_XR                              (IS_IPHONE && SCREEN_MAX_LENGTH == 896.0)
#define IS_IPHONE_NOTCH_DESIGN                          (IS_IPHONE_X_XS || IS_IPHONE_XSMAX_XR)
#define HOME_INDICATOR                                  (IS_IPHONE_NOTCH_DESIGN ? 34 : 0)


@interface Utils : NSObject

+ (id)sharedInstance;

// Network monitoring methods
- (void)startNetworkMonitoring;
- (void)stopNetworkMonitoring;
- (AFNetworkReachabilityStatus)getCurNetworkStatus;

- (void)showNoConnectivityAlert;
- (BOOL)checkJailBreak;

@end

NS_ASSUME_NONNULL_END
