//
//  Created by Ming Yang on 7/7/12.
//

#import <UIKit/UIKit.h>

#import "ImageCropView.h"

@interface ImageCroppedViewController : UIViewController {
    __weak IBOutlet UIImageView *imageview;
    __weak IBOutlet UIView *titleView;
    ImageCropViewController *croppedview;
}

@property (nonatomic, retain) UIImage* image;
- (void)setCropView:sender;


@end
