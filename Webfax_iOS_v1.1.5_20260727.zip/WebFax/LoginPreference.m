//
//  LoginViewController.m
//  WebFax2
//
//  Created by Seungil Shin on 2021/06/13.
//

#import <LocalAuthentication/LocalAuthentication.h>
#import <Foundation/Foundation.h>
#import "LoginPreference.h"
#import "Preferences.h"
#import "AppDelegate.h"

@interface LoginPreference()
@property (weak, nonatomic) IBOutlet UIButton *simpleLoginPassword;

@property (weak, nonatomic) IBOutlet UIView *bioView;
@property (weak, nonatomic) IBOutlet UIButton *simleLogin;
@property (weak, nonatomic) IBOutlet UIButton *bioLogin;

@end

@implementation LoginPreference

- (IBAction)changeSimpleLogin:(id)sender {
    if(_simleLogin.selected) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil
                                                message:@"간편로그인을 사용하지 않으시겠습니까?"
                                                preferredStyle:UIAlertControllerStyleAlert];

        UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
            _simleLogin.selected = NO;
            _simpleLoginPassword.hidden = YES;
            CGRect sr = _simleLogin.frame;
            CGRect br = _bioView.frame;
            br.origin.y = sr.origin.y + sr.size.height + 12;
            _bioView.frame = br;
            [self bioLogin].selected = NO;
            [self bioLogin].enabled = NO;
            [self updatePreferences:nil];
        }];
        UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"취소" style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
            [self bioLogin].enabled = YES;
            [self updatePreferences:nil];
        }];

        [alertController addAction:cancelAction];
        [alertController addAction:defaultAction];
        [self presentViewController:alertController animated:YES completion:^{}];
    }
    else {
        _simleLogin.selected = YES;
        _simpleLoginPassword.hidden = NO;
        CGRect sr = _simleLogin.frame;
        CGRect br = _bioView.frame;
        br.origin.y = sr.origin.y + sr.size.height + 32;
        _bioView.frame = br;
//        if(![Preferences sharedPreferences].simpleLogin) [self changeSimplePassword:nil];
        [self changeSimplePassword:nil];
        [self updatePreferences:nil];
    }
}

- (IBAction)changeBIOLogin:(id)sender {
    _bioLogin.selected = _bioLogin.selected ? NO : YES;
    if(_bioLogin.selected) {
        NSError *error;
        LAContext *_laContext = [[LAContext alloc] init];

        if (![_laContext canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) {
            UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil  message:@"단말기에 바이오(FaceID, TouchID) 로그인 설정이 되어 있지 않습니다."
                                           preferredStyle:UIAlertControllerStyleAlert];

            UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault
               handler:^(UIAlertAction * action) {
                _bioLogin.selected = NO;
                [self updatePreferences:nil];
            }];
            [alert addAction:defaultAction];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }
    [self updatePreferences:nil];
}

- (IBAction)changeSimplePassword:(id)sender {
    id pvc = self.presentingViewController;
    UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController *vc = [s_board instantiateViewControllerWithIdentifier:@"simple"];
    vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
    vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentViewController:vc animated:YES completion:NULL];
//    [pvc dismissViewControllerAnimated:YES completion:^{
//        [pvc presentViewController:vc animated:YES completion:NULL];
//    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    CGSize statusBarSize = [[UIApplication sharedApplication]statusBarFrame].size;
    [super viewDidLoad];
    for(UIView *view in self.view.subviews) {
        CGRect r = [view frame];
        r.origin.y += statusBarSize.height;
        view.frame = r;
    }
}

- (void)reloadView {
    _simleLogin.selected = ([Preferences sharedPreferences].useSimple && [Preferences sharedPreferences].simpleLogin) ? YES : NO;
    _bioLogin.selected = (_simleLogin.selected && [Preferences sharedPreferences].useBioLogin) ? YES : NO;
    _simpleLoginPassword.hidden = [Preferences sharedPreferences].useSimple ? NO : YES;
    CGRect sr = _simleLogin.frame;
    CGRect br = _bioView.frame;
    if(_simpleLoginPassword.hidden) br.origin.y = sr.origin.y + sr.size.height + 12;
    else br.origin.y = sr.origin.y + sr.size.height + 32;
    _bioView.frame = br;
    _bioView.backgroundColor = [UIColor whiteColor];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reloadView];
}

- (IBAction)updatePreferences:sender
{
    id pvc = self.presentingViewController;
    
    [Preferences sharedPreferences].useSimple  = _simleLogin.selected;
    [Preferences sharedPreferences].useBioLogin = _bioLogin.selected;
    [[Preferences sharedPreferences] save];
    if(sender)
    {
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil  message:@"설정되었습니다."
                                       preferredStyle:UIAlertControllerStyleAlert];

        UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault
           handler:^(UIAlertAction * action) {
            [pvc dismissViewControllerAnimated:YES completion:^{
                 }];
        }];
        [alert addAction:defaultAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
}


- (IBAction)closeSimple:(id)sender {
    id pvc = self.presentingViewController;
   [pvc dismissViewControllerAnimated:YES completion:^{
        }];
}

@end

