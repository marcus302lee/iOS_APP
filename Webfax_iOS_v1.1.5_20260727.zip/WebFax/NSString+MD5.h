//
//  NSString+MD5.h
//  MomiParent
//
//  Created by Lee SeungWoo on 2013. 12. 3..
//  Copyright (c) 2013년 jness. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)

- (NSString*)md5String;
- (NSString *)reverseString;
- (NSString *)makeKeyCode;


@end
