//
//  NSString+AESCrypt.h
//
//  AES128Encryption + Base64Encoding
//

#import <Foundation/Foundation.h>
#import <Foundation/NSData.h>
#import "NSData+AESCrypt.h"

@interface NSString (AESCrypt)

- (NSString*)AES128EncryptWithKey:(NSString*)key vector:(NSString*)vector;
- (NSString*)AES128DecryptWithKey:(NSString*)key vector:(NSString*)vector;
@end
