//
//  MaskView.m
//
//  Created by Ming Yang on 7/7/12.
//

#import "ImageCroppedViewController.h"
#import "ImageCropView.h"
#import "Utils.h"

@implementation ImageCroppedViewController

- (void)viewDidLoad {
    CGSize statusBarSize = [[UIApplication sharedApplication] statusBarFrame].size;
    CGRect r = [titleView frame];
    r.origin.y += statusBarSize.height;
    titleView.frame = r;
    
    CGRect ir = CGRectMake(8, CGRectGetMaxY(r) + 8, self.view.bounds.size.width - 16, self.view.bounds.size.height - CGRectGetMaxY(r) - 16 - HOME_INDICATOR);
    imageview.frame = ir;

    imageview.image = self.image;
}

- (void)setCropView:sender {
    croppedview = sender;
}

- (IBAction)cancel:(id)sender
{
  [croppedview cropCancel:self];
}

- (IBAction)cropBarButtonClick:(id)sender
{
    [croppedview selectCrop:self didFinishCroppingImage:imageview.image];
}

@end

