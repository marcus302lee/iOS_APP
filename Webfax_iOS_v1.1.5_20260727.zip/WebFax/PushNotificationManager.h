//
//  PushNotificationManager.h
//  WebFax
//
//  Created by Kim BaeSung on 2021/12/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@import Firebase;

@interface PushNotificationManager : NSObject

+ (instancetype)sharedInstance;

- (void)registerForRemoteNotifications;
-(NSString*)getFcmToken;

@end

NS_ASSUME_NONNULL_END
