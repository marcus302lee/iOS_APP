//
//  Preferences.m
//  WebFax2
//
//  Created by Seungil Shin on 2021/06/13.
//

#import <Foundation/Foundation.h>
#import "Preferences.h"
#import <Security/Security.h>

@implementation Preferences
//@synthesize userID, userPW, companyID;

#define PREF_USERID             @"UserID"
#define PREF_USERPW             @"UserPW"
#define PREF_BIO             @"BIOLogin"
#define PREF_SIMPLE             @"SimpleLogin"
#define PREF_SIMPLELOGIN          @"SimpleLoginNo"
#define PREF_PERMISSION          @"ShowPermission"




Preferences *shared_preferences = nil;

+ (Preferences *)sharedPreferences
{
    if(shared_preferences == nil) {
        shared_preferences = [[Preferences alloc] init];
    }
    return shared_preferences;
}

- (NSMutableDictionary *)keychainQueryForKey:(NSString *)key {
    return [@{(__bridge id)kSecClass : (__bridge id)kSecClassGenericPassword,
              (__bridge id)kSecAttrService : key,
              (__bridge id)kSecAttrAccount : key,
              (__bridge id)kSecAttrAccessible : (__bridge id)kSecAttrAccessibleAfterFirstUnlock
              } mutableCopy];
}

+ (void)updateString:(NSString *)str forKey:(NSString *)key userDefault:(NSUserDefaults *)def
{
    if(str && str.length > 0) {
        [def setObject:str forKey:key];
    }
    else {
        [def removeObjectForKey:key];
    }
}

+ (void)updateValue:(NSNumber *)num forKey:(NSString *)key userDefault:(NSUserDefaults *)def
{
    if(num && [num intValue] > 0) {
        [def setObject:num forKey:key];
    }
    else {
        [def removeObjectForKey:key];
    }
}

+ (void)updaeBool:(BOOL)val forKey:(NSString *)key userDefault:(NSUserDefaults *)def
{
    [def setBool:val forKey:key];
}

- (NSString *)getSecData:(NSString *)key {
    CFTypeRef result;
    NSDictionary *search = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: key,
        (__bridge id)kSecReturnData: @YES,
    };
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)search, &result);
    if( status == errSecSuccess ) {
        NSData *data = (__bridge_transfer NSData *)result;
        NSString *retStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        return retStr;
    }
    
    return nil;
}

- (OSStatus)setSecData:(NSString*)key value:(NSString*)value {
    if( value == nil ) {
        NSDictionary *search = @{
            (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
            (__bridge id)kSecAttrService: key,
            (__bridge id)kSecReturnData: @YES
        };
        return SecItemDelete((__bridge CFDictionaryRef)search);
    }
    else {
        if( [self getSecData:key] != nil ) {
            NSDictionary *search = @{
                (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
                (__bridge id)kSecAttrService: key,
            };
            NSDictionary *data = @{
                (__bridge id)kSecValueData: [value dataUsingEncoding:NSUTF8StringEncoding],
            };
            return SecItemUpdate((__bridge CFDictionaryRef)search, (__bridge CFDictionaryRef)data);
        }
        else {
            NSDictionary *search = @{
                (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
                (__bridge id)kSecAttrService: key,
                (__bridge id)kSecReturnData: @YES,
                (__bridge id)kSecValueData: [value dataUsingEncoding:NSUTF8StringEncoding],
            };
            return SecItemAdd((__bridge CFDictionaryRef)search, NULL);
        }
    }
}

- init {
    self = [super init];
    if(self) {
        NSUserDefaults *std_def = [NSUserDefaults standardUserDefaults];
        self.userID = [std_def stringForKey:PREF_USERID];
        self.userPW = [std_def stringForKey:PREF_USERPW];
        self.useBioLogin = [std_def boolForKey:PREF_BIO];
        self.useSimple = [std_def boolForKey:PREF_SIMPLE];
        self.simpleLogin = [std_def stringForKey:PREF_SIMPLELOGIN];
        self.showPermission = [std_def boolForKey:PREF_PERMISSION];
        
        // A4soft: Migration to Keychain
        BOOL isMigrated = FALSE;
        if( self.userPW != nil ) {
            if( [self setSecData:PREF_USERPW value:self.userPW] == errSecSuccess ) {
                [std_def removeObjectForKey:PREF_USERPW];
                isMigrated = TRUE;
            }
        } else {
            self.userPW = [self getSecData:PREF_USERPW];
        }
        
        if( self.simpleLogin != nil ) {
            if( [self setSecData:PREF_SIMPLELOGIN value:self.simpleLogin] == errSecSuccess ) {
                [std_def removeObjectForKey:PREF_SIMPLELOGIN];
                isMigrated = TRUE;
            }
        } else {
            self.simpleLogin = [self getSecData:PREF_SIMPLELOGIN];
        }
        
        if( isMigrated ) {
            [std_def synchronize];
        }
    }
    return self;
}

- (void)save
{
    NSUserDefaults *std_def = [NSUserDefaults standardUserDefaults];
    [Preferences  updateString:self.userID forKey:PREF_USERID userDefault:std_def];
    //[Preferences  updateString:self.userPW forKey:PREF_USERPW userDefault:std_def];
    [Preferences  updaeBool:self.useBioLogin forKey:PREF_BIO userDefault:std_def];
    [Preferences  updaeBool:self.useSimple forKey:PREF_SIMPLE userDefault:std_def];
    //[Preferences  updateString:self.simpleLogin forKey:PREF_SIMPLELOGIN userDefault:std_def];
    [Preferences updaeBool:self.showPermission forKey:PREF_PERMISSION userDefault:std_def];
    
    [std_def synchronize];
    
    
    [self setSecData:PREF_USERPW value:self.userPW];
    [self setSecData:PREF_SIMPLELOGIN value:self.simpleLogin];
}


- (NSString *)faxURL
{
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    NSString *server_url = [infoDic objectForKey:@"ServerURL"];
    return [NSString stringWithFormat:@"https://%@/m", server_url];
}

- (NSString *)faxHost
{
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    return [infoDic objectForKey:@"ServerURL"];
}

@end

