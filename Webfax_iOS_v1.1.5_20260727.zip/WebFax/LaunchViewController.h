//
//  LaunchViewController.h
//  lgupluscar
//
//  Created by Seungil Shin on 2021/09/05.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LaunchViewController : UIViewController

- (void)showMainController;

@end

NS_ASSUME_NONNULL_END
