//
//  InsetTextField.h
//  WebFax2
//
//  Created by Seungil Shin on 2021/07/23.
//

#import <UIKit/UITextField.h>

@interface InsetTextField : UITextField

@end

