//
//  ViewController.h
//  WebViewTest
//
//  Created by Seungil Shin on 2021/12/07.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <MBProgressHUD.h>
#import "ImageCropView.h"


@interface ViewController : UIViewController <WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler, UIImagePickerControllerDelegate, ImageCropViewControllerDelegate,  UIImagePickerControllerDelegate>
{
    MBProgressHUD *HUD;
    IBOutlet WKWebView *webview;
    BOOL loggedin;
    IBOutlet UILabel *lblName;
    IBOutlet UIButton *btn_Back;

}

@property (nonatomic, retain)  NSString *loadURL;
@property (nonatomic, assign) BOOL isLoggined;


@end

