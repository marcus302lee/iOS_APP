//
//  PermViewController.m
//  WebFax
//
//  Created by Oh Hansub on 2/13/24.
//

#import <Foundation/Foundation.h>
#import "Preferences.h"
#import "AppDelegate.h"
#import "PermViewController.h"
#import "LaunchViewController.h"
#import "SimpleLoginViewController.h"
#import "ViewController.h"
#import <LocalAuthentication/LocalAuthentication.h>

@interface PermViewController ()
{
}

@property (weak, nonatomic) IBOutlet UIView *btnFinish;
@property (weak, nonatomic) IBOutlet UIView *btnNext;

@end

@implementation PermViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    _btnFinish.layer.borderWidth = 1.0f;
    [_btnFinish.layer setBorderColor:[UIColor colorWithRed:219.0/255.0 green:219.0/255.0 blue:219.0/255.0 alpha:1.0].CGColor];
    
    [_btnFinish setTag:1001];
    [_btnFinish setUserInteractionEnabled:YES];
    [_btnNext setTag:1002];
    [_btnNext setUserInteractionEnabled:YES];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTap:)];
    [_btnFinish addGestureRecognizer:tap];
    
    tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTap:)];
    [_btnNext addGestureRecognizer:tap];
}

- (void)onTap:(UITapGestureRecognizer *)recognizer
{
    NSInteger tag = recognizer.view.tag;
    if( tag == 1001 ) {
        [[UIApplication sharedApplication] performSelector:@selector(suspend)];
    }
    else if( tag == 1002 ) {
        [[Preferences sharedPreferences] setShowPermission:YES];
        [[Preferences sharedPreferences] save];
        
        [self dismissViewControllerAnimated:YES completion:^{
            UIViewController *topController = [UIApplication sharedApplication].keyWindow.rootViewController;
            if( [topController isKindOfClass:[LaunchViewController class]] ) {
                LaunchViewController* lvc = (LaunchViewController*)topController;
                [lvc showMainController];
            }
            else {
                [self showMainController];
            }
            
        }];
    }
}

- (void)showMainController {
    
    [[AppDelegate sharedAppDelegate] regRemoteNotification];
    
    UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    if([Preferences sharedPreferences].useBioLogin) {
        [self useTouchID];
        return;
    }
    id havelogin = [Preferences sharedPreferences].simpleLogin;
    if([Preferences sharedPreferences].useSimple && havelogin) {
        SimpleLoginViewController *sc = [s_board instantiateViewControllerWithIdentifier:@"simple"];
        sc.isLogin = YES;
        sc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        sc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentViewController:sc animated:YES completion:nil];
    }
    else {
        ViewController *main_vc = [s_board instantiateViewControllerWithIdentifier:@"mainVC"];
        main_vc.loadURL = Preferences.sharedPreferences.faxURL;
        main_vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        main_vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentViewController:main_vc animated:YES completion:nil];
    }
}

-(void)useTouchID {
    NSError *error;
    LAContext *_laContext = [[LAContext alloc] init];

    if ([_laContext canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) { _laContext.localizedFallbackTitle = @"바이오";
        [_laContext evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:@"바이오" reply:^(BOOL succes, NSError *error) {
            if (succes) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    ViewController *main_vc = [s_board instantiateViewControllerWithIdentifier:@"mainVC"];
                    main_vc.isLoggined = YES;
                    main_vc.loadURL = Preferences.sharedPreferences.faxURL;
                    main_vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
                    main_vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
                    [self presentViewController:main_vc animated:YES completion:nil];
                });
            
            } else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    switch (error.code) {
                        case LAErrorAuthenticationFailed: { //@“터치ID 등록에 실패했습니다." //@“페이스ID 등록에 실패했습니다."
                            
                            }
                            break;
                        case LAErrorUserCancel: { //
                            
                            }
                            break;
                        case LAErrorUserFallback: break;
                        case LAErrorBiometryLockout: { //
                            
                            }
                            break;
                        default: { //
                            
                            }
                            break;
                            
                    }
                    UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    if([Preferences sharedPreferences].useSimple && [Preferences sharedPreferences].simpleLogin) {
                        SimpleLoginViewController *sc = [s_board instantiateViewControllerWithIdentifier:@"simple"];
                        sc.isLogin = YES;
                        sc.modalPresentationStyle = UIModalPresentationOverFullScreen;
                        sc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
                        [self presentViewController:sc animated:YES completion:nil];
                    }
                    else {
                        ViewController *main_vc = [s_board instantiateViewControllerWithIdentifier:@"mainVC"];
                        main_vc.loadURL = Preferences.sharedPreferences.faxURL;
                        main_vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
                        main_vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
                        [self presentViewController:main_vc animated:YES completion:nil];
                    }
                });
                
            }
            
        }];
       
    } else { //@“터치ID 설정을 확인하세요.” //@"페이스ID 설정을 확인하세요."
        UIStoryboard *s_board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ViewController *main_vc = [s_board instantiateViewControllerWithIdentifier:@"mainVC"];
        main_vc.loadURL = Preferences.sharedPreferences.faxURL;
        main_vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        main_vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentViewController:main_vc animated:YES completion:nil];
    }
}

@end
